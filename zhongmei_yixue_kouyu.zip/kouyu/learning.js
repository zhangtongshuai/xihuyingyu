$(function(){
    // /vocab/detail/{word}
    // var user_id = $.cookie('user_id'),
    //     token = $.cookie('token');
    var token = window.localStorage.getItem("token");
    var user_id = window.localStorage.getItem("user_id");
    var api ="";

    // var token ='eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjMwNTg0OCwiaXNzIjoiaHR0cDovL3Yuaml1ZGluZ2ZhbnlpLmNvbS9zdWIvbG9naW4iLCJpYXQiOjE1MjUzMzAwODEsImV4cCI6MTUyNTkzNDg4MSwibmJmIjoxNTI1MzMwMDgxLCJqdGkiOiJjeUdVTmc5Tnp3ZkhIVjFqIn0.Bx3iBnEFstuMQS9ZemWm92zzVtqmHkOPDLWA6zZD6aQ';
    // var api ="http://192.168.1.145";
    $('.once_again_record').hide();
    function GetQueryString(name)
    {
        var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if(r!=null)return  unescape(r[2]); return null;
    }
    var id = GetQueryString("id");
    //console.log(id);
    $.ajax({
        type: 'get',
        url: api + '/api/tuto/lesson/'+id+'?token=' + token,
        dataType: 'json',
        success: function (re) {
            console.log(re);
            if(re.status ==200){
                $('.to_lear_info_list').find('h3').html(re.lesson.name);
                var word=re.lesson.word;
                var html=template('tpl-word-list-info',word);
                document.getElementById('word-list-info').innerHTML=html;
                var data1=re.lesson.sentience;

                for(var i=0;i<data1.length;i++){
                    en =data1[i].en.split(/\s+/);
                    data1[i].en2 = en;
                }

                var html1=template('tpl-sentence_practice',data1);
                document.getElementById('sentence_practice').innerHTML=html1;
                
                /*点单词进行翻译*/
                $('.word').bind("click",function () {
                    $('.drawer_box1 .yinbiao').find('p').html('');
                    $('.drawer_box1 .yinbiao').find('audio').removeAttr('src');
                    $('.drawer_box1 .Chinese').find('div').find('p').html('');
                    var word1 =$(this).text().toLowerCase();
                    var word = word1.replace(/\W+/gi,'');
                    $('.drawer_box1 .English').find('.title').html(word);
                    $.ajax({
                        type: 'get',
                        url: api + '/api/vocab/detail/'+word,
                        dataType: 'json',
                        success: function (m) {
                            console.log(m);
                            if(m.pos ==null){
                                alert('未查询到释义')
                                return false;
                            }
                            if(Array.isArray(m.ps)){
                                var ysfy = '英['+m.ps[0]+']';
                                var msfy = '美['+m.ps[1]+']';
                                var ysyp = m.pron[0];
                                var msyp = m.pron[1];
                                $('.drawer_box1 .yinbiao').eq(0).find('p').html(ysfy);
                                $('.drawer_box1 .yinbiao').eq(1).find('p').html(msfy);
                                $('.drawer_box1 .yinbiao').eq(0).find('audio').attr('src',ysyp);
                                $('.drawer_box1 .yinbiao').eq(1).find('audio').attr('src',msyp);
                                $('.drawer_box1 .yinbiao').eq(1).find('img').show();
                            }else {
                                var ysfy = '英['+m.ps+']';
                                var ysyp = m.pron;
                                $('.drawer_box1 .yinbiao').eq(0).find('p').html(ysfy);
                                $('.drawer_box1 .yinbiao').eq(0).find('audio').attr('src',ysyp);
                                $('.drawer_box1 .yinbiao').eq(1).find('img').hide();
                            }
                            if(Array.isArray(m.pos)){
                                var cx0 = m.pos[0];
                                var cx1 = m.pos[1];
                                var cx2 = m.pos[2];
                                var sy0 = m.acceptation[0];
                                var sy1 = m.acceptation[1];
                                var sy2 = m.acceptation[2];
                                $('.drawer_box1 .Chinese').find('div').eq(0).find('p').eq(0).html(cx0);
                                $('.drawer_box1 .Chinese').find('div').eq(0).find('p').eq(1).html(sy0);
                                $('.drawer_box1 .Chinese').find('div').eq(1).find('p').eq(0).html(cx1);
                                $('.drawer_box1 .Chinese').find('div').eq(1).find('p').eq(1).html(sy1);
                                $('.drawer_box1 .Chinese').find('div').eq(2).find('p').eq(0).html(cx2);
                                $('.drawer_box1 .Chinese').find('div').eq(2).find('p').eq(1).html(sy2);
                            }else{
                                var cx0 = m.pos;
                                var sy0 = m.acceptation;
                                $('.drawer_box1 .Chinese').find('div').eq(0).find('p').eq(0).html(cx0);
                                $('.drawer_box1 .Chinese').find('div').eq(0).find('p').eq(1).html(sy0);
                            }
                            $.ajax({
                                type: 'get',
                                url: api + '/api/vocab/exist/?word='+word+'&token=' + token,
                                dataType: 'json',
                                success: function (n) {
                                    //console.log(n);
                                    if(n.status ==200){
                                        var vid =n.data.vid;
                                        $('.img_hui').hide();
                                        $('.img_yellow').show();
                                        $('.img_yellow').click(function () {
                                            $.ajax({
                                                type: 'get',
                                                url: api + '/api/vocab/del/?token=' + token,
                                                data:{
                                                    vid:vid
                                                },
                                                dataType: 'json',
                                                success: function (a) {
                                                    //console.log(a);
                                                    if(a.status ==200) {
                                                        $('.img_hui').show();
                                                        $('.img_yellow').hide();
                                                    }
                                                }
                                            });
                                        })
                                    }else if(n.status ==204){
                                        $('.img_hui').show();
                                        $('.img_yellow').hide();
                                        $('.img_hui').click(function () {
                                            $.ajax({
                                                type: 'get',
                                                url: api + '/api/vocab/add/?token=' + token,
                                                data:{
                                                    word:word
                                                },
                                                dataType: 'json',
                                                success: function (a) {
                                                    //console.log(a);
                                                    if(a.status ==200){
                                                        $('.img_hui').hide();
                                                        $('.img_yellow').show();
                                                    }
                                                }
                                            });
                                        })
                                    }
                                }
                            });
                            $(".drawer_box1").show();
                            $(".beij").show();
                            // $('.drawer_box1 .yinbiao:nth-of-type(1)').find('img').bind('click',function () {
                            //     enplayAudio();
                            // });
                            // $('.drawer_box1 .yinbiao:nth-of-type(2)').find('img').bind('click',function () {
                            //     amplayAudio();
                            // });

                        }
                    });
                });

                $('#requirement').html(re.lesson.requirement);
                //console.log(re.lesson.audio);
                var html2=template('tpl-wrapper_info_list',re.lesson.audio);
                document.getElementById('wrapper_info').innerHTML=html2;
                //教师示范
                $('#wrapper_info').find('ul').each(function(){
                    var teachersf = $(this);
                    var i =$(this).index();
                    teachersf.find('.img1').click(function(){

                        //alert($(this).index())
                        //console.log($(this))
                        var menud = 'way'+i;
                        //console.log(menud)
                        teachersf.find('audio').attr('id',menud)
                        var audioid = document.getElementById(menud);
                        //console.log(audioid.duration);

                        var s = audioid.duration;   //需要转的秒数
                        var m = audioid.currentTime;
                        teachersf.find('.stop_time').html(secondToDate(s));

                        // 输出05:59  分秒
                        function secondToDate(result) {
                            var m = Math.floor((result / 60 % 60)) < 10 ? '0' + Math.floor((result / 60 % 60)) : Math.floor((result / 60 % 60));
                            var s = Math.floor((result % 60)) < 10 ? '0' + Math.floor((result % 60)) : Math.floor((result % 60));
                            return result =  m + ":" + s;
                        }

                        event.stopPropagation();
                        if(audioid.paused){
                            audioid.play();
                            teachersf.find('li .img1').attr('src','images/bfbtn2.png');
                            teachersf.find('li .backbtns').addClass('zhuand')
                            setInterval(function(){
                                // m = secondToDate(m)
                                //console.log(secondToDate(audioid.currentTime) + secondToDate(s));
                                teachersf.find('.start_time').html(secondToDate(audioid.currentTime));
                                if(audioid.currentTime ==audioid.duration){
                                    audioid.pause();
                                    teachersf.find('li .img1').attr('src','images/bfbtn1.png');
                                    teachersf.find('li .backbtns').removeClass('zhuand');
                                }
                                var bfb = audioid.currentTime /audioid.duration *100;
                                //console.log(bfb)
                                teachersf.find('.progress-bar-inner').css('width',bfb + '%')
                            },1000)

                            return;
                        }else{
                            teachersf.find('li .img1').attr('src','images/bfbtn1.png');
                            teachersf.find('li .backbtns').removeClass('zhuand');
                            audioid.pause();
                            teachersf.find('.start_time').html(secondToDate(m));
                        }
                    })
                })
            }else{
                alert(re.msg);
            }
        }
    });
    var height = - $(".drawer_box1").height();
    $(".drawer_box1").css("margin-top",height);
    $(".beij").click(function(){
        $(".drawer_box1").hide();
        $(".beij").hide()
    });
//     var audio_en = $('#audio_en')[0];
//     var audio_am = $('#audio_am')[0];
// //播放暂停切换
//     function enplayAudio() {
//         if(audio_en.paused) {
//             audio_en.play();
//         } else {
//             audio_en.pause();
//         }
//     }
//     function amplayAudio() {
//         if(audio_am.paused) {
//             audio_am.play();
//         } else {
//             audio_am.pause();
//         }
//     }

    /*获取个人信息*/
    $.ajax({
        type: 'get',
        url: api + '/api/aut/info?token=' + token,
        dataType: 'json',
        success: function (re) {
            //console.log(re);
            if(re.status ==200){
               $('.to_lear_pk dl dd').find('img').attr('src','re.data.avatar');
                $('.to_lear_pk dl dd:nth-of-type(2)').html(re.data.name);
                $('.to_lear_content dl dd').eq(0).find('img').attr('src',re.data.avatar);
            }else{
                alert(re.msg);
            }
        }
    });
    /*获取PK榜*/
    $.ajax({
        type: 'get',
        url: api + '/api/tuto/lesson/'+id+'/comment'+'?token=' + token,
        dataType: 'json',
        success: function (re) {
            //console.log(re);
            if(re.status ==200){
                if(re.data!=''){
                    var data1=re.data;
                    //console.log(data1);
                    var html1=template('tpl-PK_list',data1);
                    document.getElementById('PK_list').innerHTML=html1;
                    $('.to_lear_pk').find('dl').hide();
                    var hrefid = 'cooperation.html?id='+id;
                    $('.teacher_rectify').find('a').attr('href',hrefid);
                    $('#PK_list').find('ol').each(function(){
                        $(this).click(function(){
                            //alert($(this).index())
                            //console.log($(this))
                            var menud = 'menu'+$(this).index();
                            // console.log(menud)
                            $(this).find('audio').attr('id',menud)
                            var audioid = document.getElementById(menud);
                            event.stopPropagation();
                            if(audioid.paused){
                                audioid.play();
                                $(this).find('.student_pronunciation div').css({'background':'url(images/bf2.png) no-repeat center bottom','background-size':'cover'})
                                return;
                            }else{
                                $(this).find('.student_pronunciation div').css({'background':'url(images/bf1.png) no-repeat center bottom','background-size':'cover'})
                                audioid.pause();
                            }
                            if(audioid.currentTime ==audioid.duration){
                                $(this).find('.student_pronunciation div').css({'background':'url(images/bf1.png) no-repeat center bottom','background-size':'cover'})
                                audioid.pause();
                            }
                        })
                        $(this).find('.teacher_rectify').click(function () {
                            $(this).find('.student_pronunciation div').css({'background':'url(images/bf1.png) no-repeat center bottom','background-size':'cover'})
                            audioid.pause();
                        })
                    })
                }else{
                    $('.to_lear_pk').find('dl').show();
                }
            }else{
                alert(re.msg);
            }
        }
    });

    $('.unlocking_buy_info').find('button').click(function () {
        $('.unlocking_buy_info').removeClass('show');
        $('.unlocking_buy_info').addClass('hide');
    })
    $.ajax({
        type: 'get',
        url: api + '/api/tuto/student/info?token=' + token,
        dataType: 'json',
        success: function (da) {
            //console.log(re);
            if(da.status==200){
                if(da.data!=null){
                    /*获取解锁状态*/
                    $.ajax({
                        type: 'get',
                        url: api + '/api/tuto/lesson/'+id+'/check?token=' + token,
                        dataType: 'json',
                        success: function (re) {
                            //console.log(re);
                            if(re.status ==200){
                                if(re.check==0 && re.continue==0){
                                    $('.unlocking_learn').show();
                                    $('.unlocking_learn').find('div').hide();
                                    $('.unlocking_learn').find('button').show();
                                    $('.unlocking_learn').find('button').html('每天只能解锁1篇，请明天再试');
                                    $('.once_again_record').hide();
                                    $('.study_end_record').hide();
                                    $('.study_handle_btn').hide();
                                    $('.waits_correct_tone').hide();
                                }else if (re.check==0 && re.continue==1){
                                    $('.unlocking_learn').show();
                                    $('.unlocking_learn').find('div').hide();
                                    $('.unlocking_learn').find('button').show();
                                    $('.unlocking_learn').find('button').click(function () {
                                        $.ajax({
                                            type: 'post',
                                            url: api + '/api/tuto/lesson/'+id+'/check?token=' + token,
                                            dataType: 'json',
                                            success: function (r) {
                                                //console.log(re);
                                                if(r.status ==200){
                                                    $('.unlocking_learn').hide();
                                                    $('.once_again_record').show();
                                                    $('.study_end_record').hide();
                                                    $('.study_handle_btn').hide();
                                                    $('.waits_correct_tone').hide();
                                                }else{
                                                    alert(r.msg);
                                                }
                                            }
                                        });
                                    });
                                }else if(re.check==1){
                                    $('.unlocking_learn').show();
                                    $('.unlocking_learn').find('div').hide();
                                    $('.unlocking_learn').find('button').html('每天只能解锁1篇，请明天再试');
                                    $('.once_again_record').hide();
                                    $('.study_end_record').hide();
                                    $('.study_handle_btn').hide();
                                    $('.waits_correct_tone').hide();
                                }
                            }
                        }
                    });
                }else{
                    $('.unlocking_learn').find('div').show();
                    $('.unlocking_learn').find('button').hide();

                    //去购买
                    $('#buy_btn').click(function () {
                        $('.ui-dialog-buy1').removeClass('hide');
                        $('.ui-dialog-buy1').addClass('show');
                    })
                    $('.ui-dialog-buy1').find('.buy_btn_yes button:nth-of-type(1)').click(function () {
                        $('.ui-dialog-buy1').removeClass('show');
                        $('.ui-dialog-buy1').addClass('hide');
                    });
                    $('.ui-dialog-buy1').find('.buy_btn_yes button:nth-of-type(2)').click(function () {
                        $('.ui-dialog-buy1').removeClass('show');
                        $('.ui-dialog-buy1').addClass('hide');
                        $.ajax({
                            type: 'get',
                            url: api + '/api/tuto/student/buy?token=' + token,
                            dataType: 'json',
                            success: function (re) {
                                console.log(re);
                                if(re.status ==200){
                                    alert('购买成功')
                                }else if(re.status ==4032){
                                    $('.unlocking_buy_info').removeClass('hide');
                                    $('.unlocking_buy_info').addClass('show');
                                    $('.unlocking_buy_info .ui-dialog-bd').find('p').html(re.msg);
                                    $('.unlocking_buy_info .buy_btn_yes').find('button').html('确定');
                                }else if(re.status ==4033){
                                    $('.unlocking_buy_info').removeClass('hide');
                                    $('.unlocking_buy_info').addClass('show');
                                    $('.unlocking_buy_info .ui-dialog-bd').find('p').html(re.msg);
                                    $('.unlocking_buy_info .buy_btn_yes').find('button a').attr('href','https://vedio.jiudingfanyi.com/wx/point/get');
                                    $('.unlocking_buy_info .buy_btn_yes').find('button a').html('去充值');
                                }
                            }
                        });
                    });

                }
            }else{
                alert(da.msg);
            }
        }
    });

    /*录音*/
    $('.study_handle_btn').find('#shutdown_btn').hide();
    var voice = {
        localId: '',
        serverId: ''
    };
    var commentid ='';
    var sec=0;
    var myVar;
    function myTimer(){
        myVar =setInterval(function(){
            sec++;
            if(sec>58) {
                $('.once_again_record').hide();
                $('.study_end_record').hide();
                $('.study_handle_btn').show();
                $('.waits_correct_tone').hide();
                myStopFunction();
                sec=0;
                $('.study_end_record').find('b').html('0');
            }else{
                $('.study_end_record').find('b').html(sec);
            }
        },1000);
    }
    function myStopFunction(){
        clearInterval(myVar);
    }
    var source = window.location.href;
    $.ajax({
        type: 'get',
        url: api + '/api/wx/config?source=' + source,
        dataType: 'json',
        success: function (re) {
            console.log(re);
            if (re.status == 200) {
                //console.log('调用JS-SDK');
                var timestamp = parseInt(re.data.timestamp);
                var nonceStr = re.data.nonceStr;
                var signature = re.data.signature;
                wx.config({
                    debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                    appId: re.data.appId, // 必填，公众号的唯一标识
                    timestamp: timestamp, // 必填，生成签名的时间戳
                    nonceStr: nonceStr, // 必填，生成签名的随机串
                    signature: signature,// 必填，签名，见附录1
                    jsApiList: ['startRecord','stopRecord','uploadVoice','playVoice','pauseVoice','onVoicePlayEnd'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                });
                wx.ready(function(){

                    // config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，config是一个客户端的异步操作，所以如果需要在页面加载时就调用相关接口，则须把相关接口放在ready函数中调用来确保正确执行。对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中。
                    wx.onVoicePlayEnd({
                        localId: voice.localId,
                        success: function (res) {
                            $('.study_handle_btn').find('#shutdown_btn').hide();
                            $('.study_handle_btn').find('#play_btn').show();
                            // alert('播放完毕'); // 这里用了layer弹框
                        }
                    });
                });
                wx.error(function(res){
                    // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
                });
                //按下开始录音
                $('#start_record_btn').on('click', function(event){
                    event.preventDefault();
                    START = new Date().getTime();

                    recordTimer = setTimeout(function(){
                        wx.startRecord({
                            success: function(res){
                                console.log(res)
                                localStorage.rainAllowRecord = 'true';
                                $('.once_again_record').hide();
                                $('.study_end_record').show();
                                $('.study_handle_btn').hide();
                                // $('.study_again_btn').hide();
                                $('.waits_correct_tone').hide();
                                myTimer();
                                sec=0;
                                $('.study_end_record').find('b').html('0');
                            },
                            cancel: function () {
                                alert('用户拒绝授权录音');
                            }
                        });
                    },300);
                });
                //松手结束录音
                $('#end_record_btn').on('click', function(event){
                    event.preventDefault();
                    END = new Date().getTime();

                    if((END - START) < 300){
                        END = 0;
                        START = 0;
                        //小于300ms，不录音
                        clearTimeout(recordTimer);
                    }else{
                        wx.stopRecord({
                            success: function (res) {
                                console.log(res)
                                voice.localId = res.localId;
                                // uploadVoice();
                                myStopFunction();
                                $('.once_again_record').hide();
                                $('.study_end_record').hide();
                                $('.study_handle_btn').show();
                                $('.study_handle_btn').find('#shutdown_btn').hide();
                                $('.study_handle_btn').find('#play_btn').show();
                                // $('.study_again_btn').hide();
                                $('.waits_correct_tone').hide();
                            },
                            fail: function (res) {
                                alert(JSON.stringify(res));
                            }
                        });
                    }
                });
                //重录
                $('#handle_record_btn').on('click', function(event){
                    wx.pauseVoice({
                        localId: voice.localId,
                        success: function (res) {
                            $('.study_handle_btn').find('#shutdown_btn').hide();
                            $('.study_handle_btn').find('#play_btn').show();
                        }
                    });
                    event.preventDefault();
                    START = new Date().getTime();

                    recordTimer = setTimeout(function(){
                        wx.startRecord({
                            success: function(res){
                                //console.log(res)
                                localStorage.rainAllowRecord = 'true';
                                $('.once_again_record').hide();
                                $('.study_end_record').show();
                                $('.study_handle_btn').hide();
                                // $('.study_again_btn').hide();
                                $('.waits_correct_tone').hide();
                                myTimer();
                                sec=0;
                                $('.study_end_record').find('b').html('0');
                            },
                            cancel: function () {
                                alert('用户拒绝授权录音');
                            }
                        });
                    },300);
                });
                //重新录音
                $('#handle_record_btn2').on('click', function(event){
                    $.ajax({
                        type: 'get',
                        url: api + '/api/tuto/lesson/'+id+'/comment'+'?token=' + token,
                        dataType: 'json',
                        success: function (d) {
                            //console.log(re);
                            if(d.status ==200){
                                if(d.data[0].user_id ==user_id){
                                    var commentid = d.data[0].comment_id;
                                }
                                event.preventDefault();
                                START = new Date().getTime();

                                recordTimer = setTimeout(function(){
                                    wx.startRecord({
                                        success: function(res){
                                            console.log(res)
                                            localStorage.rainAllowRecord = 'true';
                                            $('.once_again_record').hide();
                                            $('.study_end_record').show();
                                            $('.study_handle_btn').hide();
                                            // $('.study_again_btn').hide();
                                            $('.waits_correct_tone').hide();
                                            myTimer();
                                            sec=0;
                                            $('.study_end_record').find('b').html('0');
                                        },
                                        cancel: function () {
                                            alert('用户拒绝授权录音');
                                        }
                                    });
                                },300);
                            }
                        }
                    });
                    wx.pauseVoice({
                        localId: voice.localId,
                        success: function (res) {
                            $('.study_handle_btn').find('#shutdown_btn').hide();
                            $('.study_handle_btn').find('#play_btn').show();
                        }
                    });
                });

                //发布上传录音到自己的服务器
                $('#release_btn').on('click', function(event){
                    wx.pauseVoice({
                        localId: voice.localId,
                        success: function (res) {
                            $('.study_handle_btn').find('#shutdown_btn').hide();
                            $('.study_handle_btn').find('#play_btn').show();
                        }
                    });
                    if(commentid==''){
                        wx.uploadVoice({
                            localId: voice.localId, // 需要上传的音频的本地ID，由stopRecord接口获得
                            isShowProgressTips: 1, // 默认为1，显示进度提示
                            success: function (res) {
                                console.log(res)
                                voice.serverId = res.serverId;
                                //把录音在微信服务器上的id（res.serverId）发送到自己的服务器供下载。
                                var lesson_id = id;
                                var audio = res.serverId;
                                $.ajax({
                                    url: api + '/api/tuto/comment?token=' + token,
                                    type: 'post',
                                    data: {
                                        lesson_id:lesson_id,
                                        media_id:audio
                                    },
                                    dataType: "json",
                                    success: function (data) {
                                        console.log(data)
                                        if(data.status==200){
                                            alert('文件已经保存在服务器');//这回，我使用七牛存储
                                            $('.once_again_record').hide();
                                            $('.study_end_record').hide();
                                            $('.study_handle_btn').hide();
                                            // $('.study_again_btn').show();
                                            $('.waits_correct_tone').show();
                                        }else{
                                            alert(data.msg);
                                        }
                                    },
                                    error: function (xhr, errorType, error) {
                                        console.log(error);
                                    }
                                });
                            }
                        });
                    }else{
                        wx.uploadVoice({
                            localId: voice.localId, // 需要上传的音频的本地ID，由stopRecord接口获得
                            isShowProgressTips: 1, // 默认为1，显示进度提示
                            success: function (res) {
                                console.log(res)
                                voice.serverId = res.serverId;
                                //把录音在微信服务器上的id（res.serverId）发送到自己的服务器供下载。
                                var lesson_id = id;
                                var audio = res.serverId;
                                $.ajax({
                                    url: api + '/api/tuto/comment/'+commentid+'?token=' + token,
                                    type: 'post',
                                    data: {
                                        _method:'put',
                                        lesson_id:lesson_id,
                                        media_id:audio
                                    },
                                    dataType: "json",
                                    success: function (data) {
                                        console.log(data)
                                        if(data.status==200){
                                            alert('文件已经保存在服务器');//这回，我使用七牛存储
                                            $('.once_again_record').hide();
                                            $('.study_end_record').hide();
                                            $('.study_handle_btn').hide();
                                            // $('.study_again_btn').show();
                                            $('.waits_correct_tone').show();
                                            window.location.reload();
                                        }else{
                                            alert(data.msg);
                                        }
                                    },
                                    error: function (xhr, errorType, error) {
                                        console.log(error);
                                    }
                                });
                            }
                        });
                    }
                });
                //播放录音
                $('#play_btn').on('click', function(event){
                    //播放器控制
                    wx.playVoice({
                        localId: voice.localId,
                        success: function (res) {
                            $('.study_handle_btn').find('#shutdown_btn').show();
                            $('.study_handle_btn').find('#play_btn').hide();
                        }
                    });
                });
                //暂停播放
                $('#shutdown_btn').on('click', function(event){
                    wx.pauseVoice({
                        localId: voice.localId,
                        success: function (res) {
                            $('.study_handle_btn').find('#shutdown_btn').hide();
                            $('.study_handle_btn').find('#play_btn').show();
                        }
                    });
                });

                //注册微信播放录音结束事件【一定要放在wx.ready函数内】
                wx.onVoicePlayEnd({
                    success: function (res) {
                        console.log(res)
                        stopWave();
                    }
                });

                if(!localStorage.rainAllowRecord || localStorage.rainAllowRecord !== 'true'){
                    wx.startRecord({
                        success: function(res){
                            console.log(res)
                            localStorage.rainAllowRecord = 'true';
                            wx.stopRecord();
                        },
                        cancel: function () {
                            alert('用户拒绝授权录音');
                        }
                    });
                }
            }else{
                alert(re.msg);
            }
        }
    });
});