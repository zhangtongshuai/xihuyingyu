$(function(){
    $('.xihu_app').find('ol li:nth-of-type(1)').click(function () {
        src_0 = $('.xihu_app').find('ol li:nth-of-type(1) img').attr("src");
        src_1 = src_0=="images/d.png"?"images/dd.png":"images/d.png";
        $('.xihu_app').find('ol li:nth-of-type(1) img').attr("src",src_1);
        $('.xihu_app').find('ol li:nth-of-type(2) img').attr("src",'images/navbar7b.png');
        $('.xihu_app').find('ol li:nth-of-type(3) img').attr("src",'images/navbar8b.png');
        $('.xihu_app').find('ol li:nth-of-type(4) img').attr("src",'images/navbar8b.png');
    })
    $('.xihu_app').find('ol li:nth-of-type(2)').click(function () {
        src_0 = $('.xihu_app').find('ol li:nth-of-type(2) img').attr("src");
        src_1 = src_0=="images/navbar7b.png"?"images/navbar7a.png":"images/navbar7b.png";
        $('.xihu_app').find('ol li:nth-of-type(2) img').attr("src",src_1);
        $('.xihu_app').find('ol li:nth-of-type(1) img').attr("src",'images/d.png');
        $('.xihu_app').find('ol li:nth-of-type(3) img').attr("src",'images/navbar8b.png');
        $('.xihu_app').find('ol li:nth-of-type(4) img').attr("src",'images/navbar8b.png');
    })
    $('.xihu_app').find('ol li:nth-of-type(3)').click(function () {
        src_0 = $('.xihu_app').find('ol li:nth-of-type(3) img').attr("src");
        src_1 = src_0=="images/navbar8b.png"?"images/navbar8a.png":"images/navbar8b.png";
        $('.xihu_app').find('ol li:nth-of-type(3) img').attr("src",src_1);
        $('.xihu_app').find('ol li:nth-of-type(1) img').attr("src",'images/d.png');
        $('.xihu_app').find('ol li:nth-of-type(2) img').attr("src",'images/navbar7b.png');
        $('.xihu_app').find('ol li:nth-of-type(4) img').attr("src",'images/navbar8b.png');
    })
    $('.xihu_app').find('ol li:nth-of-type(4)').click(function () {
        src_0 = $('.xihu_app').find('ol li:nth-of-type(4) img').attr("src");
        src_1 = src_0=="images/navbar8b.png"?"images/navbar4a.png":"images/navbar4b.png";
        $('.xihu_app').find('ol li:nth-of-type(4) img').attr("src",src_1);
        $('.xihu_app').find('ol li:nth-of-type(1) img').attr("src",'images/d.png');
        $('.xihu_app').find('ol li:nth-of-type(2) img').attr("src",'images/navbar7b.png');
        $('.xihu_app').find('ol li:nth-of-type(3) img').attr("src",'images/navbar8b.png');
    })
    //jQuery
    // var user_id = $.cookie('user_id'),
    //     jwt_token = $.cookie('jwt_token');
    var token = window.localStorage.getItem("token");
    var api ="";
    // var token ='eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjMwNTg0OCwiaXNzIjoiaHR0cDovL3Yuaml1ZGluZ2ZhbnlpLmNvbS9zdWIvbG9naW4iLCJpYXQiOjE1MjUzMzAwODEsImV4cCI6MTUyNTkzNDg4MSwibmJmIjoxNTI1MzMwMDgxLCJqdGkiOiJjeUdVTmc5Tnp3ZkhIVjFqIn0.Bx3iBnEFstuMQS9ZemWm92zzVtqmHkOPDLWA6zZD6aQ';
    // var api ="http://192.168.1.145";


    $('.tab').find('li').click(function(){
        var index = $(this).index();
        $(this).addClass('active').siblings().removeClass('active');
        $('.content').find('li').eq(index).show().siblings().hide();
    });

    $('.content .learning').find('dd').click(function(){
        $(this).addClass('now').siblings().removeClass('now');
    });
    $('#checked_major').click(function(){
        $('.choice_major').css('margin-left','0');
        $('.bg').css('display','block');
    });
    $('.bg').click(function () {
        $('.choice_major').css('margin-left','-610px');
        $('.bg').css('display','none');
    })
//learning和study页面的返回上一个页面的按钮判断
    function GetQueryString(name)
    {
        var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if(r!=null)return  unescape(r[2]); return null;
    }

    function add0(m){return m<10?'0'+m:m }
//时间戳转化成时间格式

    sessionStorage.setItem("sort", "1");
    if(GetQueryString("key")){
        var key = GetQueryString("key");

        var now_majorid = sessionStorage.getItem('majorid');
        var now_majorinfo = sessionStorage.getItem('majorinfo');
        var now_sort = sessionStorage.getItem('sort');

        if(key ==1){
            $('.tab').find('li').removeClass('active');
            $('.tab').find('li:nth-of-type(2)').addClass('active');
            $('.content').find('.abstract').css('display','none');
            $('.content').find('.learning').css('display','block');
            $('.content').find('.studied').css('display','none');
            if(now_sort ==1){
                $('.learning dl').find('dd').removeClass('now');
                $('.learning dl').find('dd:nth-of-type(1)').addClass('now');
                $.ajax({
                    type: 'get',
                    url: api + '/api/tuto/lesson?token=' + token + '&learned='+0+'&order='+2,
                    dataType: 'json',
                    success: function (re) {
                        console.log(re);
                        if(re.status ==200){
                            var data=re.data;
                            var html=template('tpl-learn-list-info',data);
                            document.getElementById('learn-list-info').innerHTML=html;
                        }else{
                            alert(re.msg);
                        }
                    }
                });
            }else if(now_sort ==2){
                $('.learning dl').find('dd').removeClass('now');
                $('.learning dl').find('dd:nth-of-type(2)').addClass('now');
                $.ajax({
                    type: 'get',
                    url: api + '/api/tuto/lesson?token=' + token + '&learned='+0+'&order='+1,
                    dataType: 'json',
                    success: function (re) {
                        console.log(re);
                        if(re.status ==200){
                            var data=re.data;
                            var html=template('tpl-learn-list-info',data);
                            document.getElementById('learn-list-info').innerHTML=html;
                        }else{
                            alert(re.msg);
                        }
                    }
                });
            }else if(now_sort ==3){
                $('.learning dl').find('dd').removeClass('now');
                $('.learning dl').find('dd:nth-of-type(3)').addClass('now');
                $('.learning dl').find('dd:nth-of-type(3)').find('span:nth-of-type(1)').html(now_majorid);
                $('.learning dl').find('dd:nth-of-type(3)').find('span:nth-of-type(2)').html(now_majorinfo);
                $.ajax({
                    type: 'get',
                    url: api + '/api/tuto/lesson?token=' + token + '&learned='+0+'&tag='+now_majorid,
                    dataType: 'json',
                    success: function (re) {
                        //console.log(re);
                        if(re.status ==200){
                            var data=re.data;
                            var html=template('tpl-learn-list-info',data);
                            document.getElementById('learn-list-info').innerHTML=html;
                        }else{
                            alert(re.msg);
                        }
                    }
                });
            }
        }else if(key == 2){
            $('.tab').find('li').removeClass('active');
            $('.tab').find('li:nth-of-type(3)').addClass('active');
            $('.content').find('.abstract').css('display','none');
            $('.content').find('.learning').css('display','none');
            $('.content').find('.studied').css('display','block');
            $.ajax({
                type: 'get',
                url: api + '/api/tuto/lesson?token=' + token + '&learned='+1,
                dataType: 'json',
                success: function (r) {
                    console.log(r)
                    if(r.status ==200){
                        var data=r.data;
                        var html=template('tpl-studied-list-info',data);
                        document.getElementById('studied-list-info').innerHTML=html;
                    }else{
                        alert(r.msg);
                    }
                }
            });
        }
    }else{
        //未购买默认显示简介  ,已购买默认显示待学习
        $.ajax({
            type: 'get',
            url: api + '/api/tuto/student/info?token=' + token,
            dataType: 'json',
            success: function (r) {
                console.log(r)
                if(r.status ==200){
                    if(r.data != null){
                        var woDate = new Date();
                        var mynewDay =woDate.getTime();
                        var mdate = new Date(r.data.expired_at);
                        var time1 = mdate.getTime();
                        //console.log(mynewDay)
                        //console.log(time1)
                        if(time1>mynewDay){
                            $('.tab').find('li:nth-of-type(1)').removeClass('active');
                            $('.tab').find('li:nth-of-type(2)').addClass('active');
                            $('.content').find('.abstract').css('display','none');
                            $('.content').find('.learning').css('display','block');
                            $('.content .abstract .oral_buy').find('.oral_buy_start').css('display','none');
                            $('.content .abstract .oral_buy').find('.oral_buy_end').css('display','block');
                            var time = new Date(time1);
                            var year = time.getFullYear();
                            var month = time.getMonth()+1;
                            var date = time.getDate();
                            var expiry_time =  year+'年'+add0(month)+'月'+add0(date)+'日';
                            $('.oral_buy .oral_buy_end').find('span').html(expiry_time);
                            $.ajax({
                                type: 'get',
                                url: api + '/api/tuto/lesson?token=' + token + '&learned='+0+'&order='+2,
                                dataType: 'json',
                                success: function (re) {
                                    //console.log(re);
                                    if(re.status ==200){
                                        var data=re.data;
                                        var html=template('tpl-learn-list-info',data);
                                        document.getElementById('learn-list-info').innerHTML=html;
                                    }else{
                                        alert(re.msg);
                                    }
                                }
                            });
                        }else{
                            $('.tab').find('li:nth-of-type(1)').addClass('active');
                            $('.tab').find('li:nth-of-type(2)').removeClass('active');
                            $('.content').find('.abstract').css('display','block');
                            $('.content').find('.learning').css('display','none');
                            $('.content .abstract .oral_buy').find('.oral_buy_start').css('display','block');
                            $('.content .abstract .oral_buy').find('.oral_buy_end').css('display','none');
                        }
                    }else{
                        $('.tab').find('li:nth-of-type(1)').addClass('active');
                        $('.tab').find('li:nth-of-type(2)').removeClass('active');
                        $('.content').find('.abstract').css('display','block');
                        $('.content').find('.learning').css('display','none');
                        $('.content .abstract .oral_buy').find('.oral_buy_start').css('display','block');
                        $('.content .abstract .oral_buy').find('.oral_buy_end').css('display','none');
                    }
                }else{
                    alert(r.msg);
                }
            }
        });
    }

    $('.learning dl').find('dd:nth-of-type(1)').click(function () {
        sessionStorage.setItem("sort", "1");
        //最多学习列表
        $.ajax({
            type: 'get',
            url: api + '/api/tuto/lesson?token=' + token + '&learned='+0+'&order='+2,
            dataType: 'json',
            success: function (re) {
                console.log(re);
                if(re.status ==200){
                    var data=re.data;
                    var html=template('tpl-learn-list-info',data);
                    document.getElementById('learn-list-info').innerHTML=html;
                }else{
                    alert(re.msg);
                }
            }
        });
    });
    $('.learning dl').find('dd:nth-of-type(2)').click(function () {
        sessionStorage.setItem("sort", "2");
        //最新更新列表
        $.ajax({
            type: 'get',
            url: api + '/api/tuto/lesson?token=' + token + '&learned='+0+'&order='+1,
            dataType: 'json',
            success: function (re) {
                console.log(re);
                if(re.status ==200){
                    var data=re.data;
                    var html=template('tpl-learn-list-info',data);
                    document.getElementById('learn-list-info').innerHTML=html;
                }else{
                    alert(re.msg);
                }
            }
        });
    });

    $('.learning dl').find('dd:nth-of-type(3)').click(function () {
        //专业列表
        sessionStorage.setItem("sort", "3");
        var majorid = $('.learning dl').find('dd:nth-of-type(3) span:nth-of-type(1)').html();
        var checkinfo = $('.learning dl').find('dd:nth-of-type(3) span:nth-of-type(2)').html();
        sessionStorage.setItem("majorid", majorid);
        sessionStorage.setItem("majorinfo", checkinfo);
        $.ajax({
            type: 'get',
            url: api + '/api/tuto/lesson?token=' + token + '&learned='+0+'&tag='+majorid,
            dataType: 'json',
            success: function (re) {
                //console.log(re);
                if(re.status ==200){
                    var data=re.data;
                    var html=template('tpl-learn-list-info',data);
                    document.getElementById('learn-list-info').innerHTML=html;
                }else{
                    alert(re.msg);
                }
            }
        });
    });

    //购买课程
    $('.content .oral_buy .oral_buy_start').find('.buy_btn').click(function () {
        $('.ui-dialog-buy').removeClass('hide');
        $('.ui-dialog-buy').addClass('show');
    });
    $('.ui-dialog-buy').find('.buy_btn_yes button:nth-of-type(1)').click(function () {
        $('.ui-dialog-buy').removeClass('show');
        $('.ui-dialog-buy').addClass('hide');
    });
    $('.ui-dialog-buy').find('.buy_btn_yes button:nth-of-type(2)').click(function () {
        $('.ui-dialog-buy').removeClass('show');
        $('.ui-dialog-buy').addClass('hide');
        $.ajax({
            type: 'get',
            url: api + '/api/tuto/student/buy?token=' + token,
            dataType: 'json',
            success: function (r) {
                console.log(r)
                if(r.status ==200){
                    $('.content .abstract .oral_buy').find('.oral_buy_start').css('display','none');
                    $('.content .abstract .oral_buy').find('.oral_buy_end').css('display','block');
                    // window.location.reload();
                    alert('恭喜您购买成功');
                }else{
                    alert(r.msg);
                }
            }
        });
    });
    //简介页面
    $('.tab').find('li:nth-of-type(1)').click(function () {
        $.ajax({
            type: 'get',
            url: api + '/api/tuto/student/info?token=' + token,
            dataType: 'json',
            success: function (r) {
                //console.log(r)
                if(r.status ==200){
                    if(r.data != null){
                        var woDate = new Date();
                        var mynewDay =woDate.getTime();
                        var mdate = new Date(r.data.expired_at);
                        var time1 = mdate.getTime();
                        if(time1>mynewDay){
                            var time = new Date(time1);
                            var year = time.getFullYear();
                            var month = time.getMonth()+1;
                            var date = time.getDate();
                            var expiry_time =  year+'年'+add0(month)+'月'+add0(date)+'日';
                            $('.oral_buy .oral_buy_end').find('span').html(expiry_time);
                            $('.content .abstract .oral_buy').find('.oral_buy_start').css('display','none');
                            $('.content .abstract .oral_buy').find('.oral_buy_end').css('display','block');
                        }else{
                            $('.content .abstract .oral_buy').find('.oral_buy_start').css('display','block');
                            $('.content .abstract .oral_buy').find('.oral_buy_end').css('display','none');
                        }
                    }else{
                        $('.content .abstract .oral_buy').find('.oral_buy_start').css('display','block');
                        $('.content .abstract .oral_buy').find('.oral_buy_end').css('display','none');
                    }
                }else{
                    alert(r.msg);
                }
            }
        });
    })

    //待学习列表
    $('.tab').find('li:nth-of-type(2)').click(function () {
        //console.log(1)
        $.ajax({
            type: 'get',
            url: api + '/api/tuto/lesson?token=' + token + '&learned='+0+'&order='+2,
            dataType: 'json',
            success: function (re) {
                console.log(re);
                if(re.status ==200){
                    var data=re.data;
                    var html=template('tpl-learn-list-info',data);
                    document.getElementById('learn-list-info').innerHTML=html;
                }else{
                    alert(re.msg);
                }
            }
        });
    })

    //已学习列表
    $('.tab').find('li:nth-of-type(3)').click(function () {
        //console.log(1)
        $.ajax({
            type: 'get',
            url: api + '/api/tuto/lesson?token=' + token + '&learned='+1,
            dataType: 'json',
            success: function (r) {
                console.log(r)
                if(r.status ==200){
                    var data=r.data;
                    var html=template('tpl-studied-list-info',data);
                    document.getElementById('studied-list-info').innerHTML=html;
                }else{
                    alert(r.msg);
                }
            }
        });
    })
    //获取标签列表
    $.ajax({
        type: 'get',
        url: api + '/api/tuto/tag?token=' + token,
        dataType: 'json',
        success: function (m) {
            //console.log(m)
            if(m.status ==200){
                $('.learning dl').find('dd:nth-of-type(3) span:nth-of-type(1)').html(m.data[0].id);
                $('.learning dl').find('dd:nth-of-type(3) span:nth-of-type(2)').html(m.data[0].name);
                var data=m.data;
                var html=template('tpl-choice_major-list',data);
                document.getElementById('choice_major_info').innerHTML=html;

                $('.choice_major .choice_major_list li').click(function () {
                    sessionStorage.setItem("sort", "3");
                    $(this).addClass('check_major_info').siblings().removeClass('check_major_info');
                    var checkMajor = $('.choice_major .choice_major_list .check_major_info a').html();
                    var majorid = $('.choice_major .choice_major_list .check_major_info span').html();
                    sessionStorage.setItem("majorid", majorid);
                    sessionStorage.setItem("majorinfo", checkMajor);
                    $('.content .learning dl .major').find('span:nth-of-type(1)').html(majorid);
                    $('.content .learning dl .major').find('span:nth-of-type(2)').html(checkMajor);
                    $('.choice_major').css('margin-left','-610px');
                    $('.bg').css('display','none');
                    $.ajax({
                        type: 'get',
                        url: api + '/api/tuto/lesson?token=' + token + '&learned='+0+'&tag='+majorid,
                        dataType: 'json',
                        success: function (re) {
                            console.log(re);
                            if(re.status ==200){
                                var data=re.data;
                                var html=template('tpl-learn-list-info',data);
                                document.getElementById('learn-list-info').innerHTML=html;
                            }else{
                                alert(re.msg);
                            }
                        }
                    });
                })
            }else{
                alert(m.msg);
            }

        }
    });
});
